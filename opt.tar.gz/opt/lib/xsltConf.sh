#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/opt/lib"
XSLT_LIBS="-lxslt -L/home/slug/optware/oleg/staging/opt/lib -L/home/slug/optware/oleg/staging/opt/lib -lxml2 -lz -lm -lm"
XSLT_INCLUDEDIR="-I/opt/include"
MODULE_VERSION="xslt-1.1.26"
