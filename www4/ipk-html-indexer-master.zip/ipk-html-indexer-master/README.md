# ipk-html-indexer
HTML index builder for *.ipk repositories
